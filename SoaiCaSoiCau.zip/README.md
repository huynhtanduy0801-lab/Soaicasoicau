# Soái Ca Soi Cầu - Android (Kotlin)

Project skeleton for an Android app that analyzes Tài/Xỉu history and gives heuristic predictions.

## Build
1. Open in Android Studio
2. Sync Gradle
3. Build -> Build APK(s)

## Notes
- This app is educational. Do not use for actual gambling.
- To export signed APK: Build -> Generate Signed Bundle / APK -> create keystore -> sign.
