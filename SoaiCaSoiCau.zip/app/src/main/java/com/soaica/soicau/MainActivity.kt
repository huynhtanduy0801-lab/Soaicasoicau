package com.soaica.soicau

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var inputArea: EditText
    private lateinit var btnAnalyze: Button
    private lateinit var tvResult: TextView
    private lateinit var btnAddResult: Button
    private lateinit var editNewResult: EditText

    private val rounds = mutableListOf<Round>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputArea = findViewById(R.id.inputArea)
        btnAnalyze = findViewById(R.id.btnAnalyze)
        tvResult = findViewById(R.id.tvResult)
        btnAddResult = findViewById(R.id.btnAddResult)
        editNewResult = findViewById(R.id.editNewResult)

        btnAnalyze.setOnClickListener {
            val raw = inputArea.text.toString().trim()
            val lines = raw.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.size < 15) {
                Toast.makeText(this, "Nhập ít nhất 15 phiên (1 dòng 1 phiên)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            rounds.clear()
            try {
                for (i in 0 until minOf(15, lines.size)) {
                    val r = Round.parse(lines[i])
                    rounds.add(r)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Sai định dạng ở 1 trong các dòng: ví dụ 'T 665'", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val engine = PredictionEngine()
            val info = engine.analyze(rounds)
            tvResult.text = info.toDisplayString()
        }

        btnAddResult.setOnClickListener {
            val s = editNewResult.text.toString().trim()
            if (s.isEmpty()) return@setOnClickListener
            try {
                val r = Round.parse(s)
                rounds.add(r)
                val engine = PredictionEngine()
                val info = engine.analyze(rounds)
                tvResult.text = info.toDisplayString()
                editNewResult.text.clear()
            } catch (e: Exception) {
                Toast.makeText(this, "Sai format. Ví dụ 'T 665'", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

// Small data classes and helpers

data class Round(val side: Char, val dices: List<Int>, val total: Int, val raw: String) {
    companion object {
        fun parse(s: String): Round {
            val t = s.trim().uppercase()
            val parts = t.split(Regex("\\s+"))
            if (parts.size < 2) throw IllegalArgumentException("Invalid")
            val side = parts[0].first()
            val num = parts[1]
            if (side != 'T' && side != 'X') throw IllegalArgumentException("Side must be T or X")
            if (num.length != 3) throw IllegalArgumentException("Dices must be 3 digits")
            val dices = num.map { ch -> ch.digitToInt() }
            val total = dices.sum()
            return Round(side, dices, total, "${'$'}{side} ${'$'}{num}")
        }
    }
}
