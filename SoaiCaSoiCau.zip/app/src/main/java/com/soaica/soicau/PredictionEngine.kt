package com.soaica.soicau

import kotlin.math.max

class PredictionInfo(
    val pT: Double,
    val pX: Double,
    val runLen: Int,
    val runSide: Char?,
    val kép: Boolean,
    val hoi: Boolean,
    val typeCounts: Map<String, Int>,
    val pred: Char,
    val confidence: Double
) {
    fun toDisplayString(): String {
        return buildString {
            append("Dự đoán: ${'$'}pred  (tin cậy: ${'$'}{"%.3f".format(confidence)})\n")
            append("Tỷ lệ lịch sử: T=${'$'}{"%.1f".format(pT*100)}%  X=${'$'}{"%.1f".format(pX*100)}%\n")
            append("Bệt: ${'$'}{runSide ?: '-'} dài=${'$'}runLen  | Kép: ${'$'}{if (kép) "Có" else "Không"}  | Hồi: ${'$'}{if (hoi) "Có" else "Không"}\n")
            append("Loại xúc xắc: ${'$'}{typeCounts}\n")
        }
    }
}

class PredictionEngine {
    fun analyze(rounds: List<Round>): PredictionInfo {
        val n = rounds.size
        val cntT = rounds.count { it.side == 'T' }
        val cntX = rounds.count { it.side == 'X' }
        val pT = cntT.toDouble() / n
        val pX = cntX.toDouble() / n

        val (runLen, runSide) = detectRuns(rounds)
        val kep = detectKep(rounds)
        val hoi = detectHoi(rounds)
        val typeCounts = detectTypes(rounds)

        // votes
        var voteT = pT
        var voteX = pX
        if (runLen >= 4 && runSide != null) {
            if (runSide == 'T') voteT += 0.6 - (runLen - 4) * 0.1 else voteX += 0.6 - (runLen - 4) * 0.1
        }
        if (runLen == 3 && runSide != null) {
            if (runSide == 'T') voteT += 0.4 else voteX += 0.4
        }
        if (kep) {
            // bias slightly to the side that has duplicate in last 3
            val last3 = rounds.takeLast(3)
            val rawCounts = last3.groupingBy { it.raw }.eachCount()
            val dup = rawCounts.filter { it.value >= 2 }.keys.firstOrNull()
            if (dup != null) {
                val side = last3.first { it.raw == dup }.side
                if (side == 'T') voteT += 0.5 else voteX += 0.5
            }
        }
        if (hoi) {
            if (pT > pX) voteT += 0.2 else voteX += 0.2
        }
        // normalize and pick
        val total = max(1e-9, voteT + voteX)
        val pTFinal = (voteT / total).coerceIn(0.0, 1.0)
        val pXFinal = (voteX / total).coerceIn(0.0, 1.0)
        val pred = if (pTFinal >= pXFinal) 'T' else 'X'
        val confidence = kotlin.math.abs(pTFinal - pXFinal)
        return PredictionInfo(pT, pX, runLen, runSide, kep, hoi, typeCounts, pred, confidence)
    }

    private fun detectRuns(rounds: List<Round>): Pair<Int, Char?> {
        if (rounds.isEmpty()) return Pair(0, null)
        val lastSide = rounds.last().side
        var run = 1
        for (i in rounds.size - 2 downTo 0) {
            if (rounds[i].side == lastSide) run++ else break
        }
        return Pair(run, lastSide)
    }

    private fun detectKep(rounds: List<Round>): Boolean {
        if (rounds.size < 3) return false
        val last3 = rounds.takeLast(3)
        val raws = last3.map { it.raw }
        val map = raws.groupingBy { it }.eachCount()
        return map.any { it.value >= 2 }
    }

    private fun detectHoi(rounds: List<Round>): Boolean {
        if (rounds.size < 5) return false
        for (i in 0..rounds.size - 5) {
            val window = rounds.subList(i, i + 5).map { it.side }
            if (window[0] == window[1] && window[1] == window[2] && window[3] != window[0] && window[4] == window[0]) return true
        }
        return false
    }

    private fun detectTypes(rounds: List<Round>): Map<String, Int> {
        val map = mutableMapOf("triple" to 0, "pair" to 0, "alldiff" to 0)
        for (r in rounds) {
            val freq = r.dices.groupingBy { it }.eachCount()
            if (freq.values.any { it == 3 }) map["triple"] = map.getValue("triple") + 1
            else if (freq.values.any { it == 2 }) map["pair"] = map.getValue("pair") + 1
            else map["alldiff"] = map.getValue("alldiff") + 1
        }
        return map
    }
}
